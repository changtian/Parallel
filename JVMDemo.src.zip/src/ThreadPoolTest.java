import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ThreadPoolTest {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		ExecutorService threadPool = Executors.newCachedThreadPool();
		for(int i=1;i<=3; i++)
		{
			final int task = i;
			threadPool.execute(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					
				}
			});
		}
		
		
		ExecutorService executor = Executors.newFixedThreadPool(10);
		CompletionService completionService = new ExecutorCompletionService<>(executor);
		for(int i=1;i<=10;i++)
		{
			final int result = i;
			completionService.submit(new Callable(){

				@Override
                public Object call() throws Exception {
	                // TODO Auto-generated method stub
					Thread.sleep(new Random().nextInt(5000));
	                return result;
                }});
		}
		
		System.out.println(completionService.take().get());
		
		
		//new SingleThreadExecutor()
		//new ScheduledThreadPool(int corePoolSize) 
		//new SingleThreadScheduledExecutor() 
		
	}

}
