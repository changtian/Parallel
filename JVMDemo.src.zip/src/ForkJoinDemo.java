import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;

public class ForkJoinDemo {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		ForkJoinPool pool = new ForkJoinPool();//equal to cpu core num, 
		SumTask task = new SumTask(1, 100);
		Future<Integer> f = pool.submit(task);
		
		System.out.println(f.get());//都是守护线程
		
	}

}

class SumTask extends RecursiveTask<Integer> {
	private int from;
	private int to;
	public SumTask(int from, int to) {
		super();
		this.from = from;
		this.to = to;
		System.out.println(from + " -- " + to);
	}
	@Override
	protected Integer compute() {
		Integer result = 0;
		// TODO Auto-generated method stub
		if(to-from>25)
		{
			SumTask left = new SumTask(from, (to+from)/2);
			SumTask right = new SumTask((to+from)/2+1, to);
			left.fork();
			right.fork();//不阻塞
			result = left.join()+right.join();//阻塞， 小心使用
		}
		
		for(int i=from; i<=to; i++){
			result +=i;
		}
		return result;
	}
	
}
