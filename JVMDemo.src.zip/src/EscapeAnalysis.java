
public class EscapeAnalysis {
	 private static class Foo {
	        private int x;
	        private static int counter;

	        public Foo() {
	            x = (++counter);
	        }
	    }
	    public static void main(String[] args) {
	        System.out.println("start");
	        
	        long start = System.currentTimeMillis();
	        for (int i = 0; i < 10000000; ++i) {
	            Foo foo = new Foo();
	        }

	        long after = System.currentTimeMillis();
	        System.out.println(Foo.counter);
	        
	        System.out.println(after-start);
	    }
}
