package rpc;

public interface HelloService {
	String sayHi(String name);
}
