package rpc;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ServiceCenter implements Server{
	private static ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
	
	private static final HashMap<String, Class> serviceRegistry = new HashMap<>();
	
	private static boolean isRunning = false;
	
	private static int port;
	
	public ServiceCenter(int port)
	{
		this.port = port;
	}
	
	public void stop()
	{
		isRunning = false;
		executor.shutdown();
	}
	
	public void start() throws IOException{
		ServerSocket server = new ServerSocket();
		server.bind(new InetSocketAddress(port));
		System.out.println("start server");
		try{
			while(true)
			{
				executor.execute(new ServiceTask(server.accept()));
			}
		}
		finally{
			server.close();
		}
	}
	
	public void register(Class serviceInterface, Class impl)
	{
		serviceRegistry.put(serviceInterface.getName(), impl);
	}
	
	public boolean isRunning()
	{
		return isRunning;
	}
	
	public int getPort()
	{
		return port;
	}
	
	private static class ServiceTask implements Runnable{
		Socket client = null;
		
		public ServiceTask(Socket client)
		{
			this.client = client;
		}
		@Override
        public void run() {
	        // TODO Auto-generated method stub
	        ObjectInputStream input = null;
	        ObjectOutputStream output = null;
	        
	        try {
	            input = new ObjectInputStream(client.getInputStream());
	            String serviceName = input.readUTF();
	            String methodName = input.readUTF();
	            
	            Class<?>[] parameterTypes = (Class<?>[]) input.readObject();
	            Object[] argumetns = (Object[])input.readObject();
	            Class serviceClass = serviceRegistry.get(serviceName);
	            if(serviceClass == null)
	            {
	            	throw new ClassNotFoundException(serviceName + " not found");
	            }
	            
	            java.lang.reflect.Method method = serviceClass.getMethod(methodName, parameterTypes);
	            
	            Object result = method.invoke(serviceClass.newInstance(), argumetns);
	            output = new ObjectOutputStream(client.getOutputStream());
	            output.writeObject(result);
	            
            } catch (IOException | ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | InstantiationException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }finally{
            	if(output!=null)
            	{
            		try{
            			output.close();
            		}catch(IOException ex)
            		{
            			
            		}
            	}
            	
            	if(input!=null)
            	{
            		try{
            			input.close();
            		}catch(IOException ex)
            		{
            			
            		}
            	}
            	
            	if(client !=null)
            	{
            		try{client.close();}catch(IOException ex)
            		{
            			
            		}
            	}
            	
            }
	        
	        
        }
		
	}
	
}
