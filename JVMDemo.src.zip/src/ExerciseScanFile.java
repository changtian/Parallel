import java.io.File;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class ExerciseScanFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		scanSingleThread(new File("/users"));
		
		
		System.out.println("active: "+ Thread.activeCount());
		System.out.println("core: " + Runtime.getRuntime().availableProcessors());
	
		//Thread.activeCount()>Runtime.getRuntime().availableProcessors()-2
		while(pool.getActiveCount()>0)
		{
			Thread.yield();
		}
		pool.shutdown();
		long after = System.currentTimeMillis();
		System.out.println(after-start);
	}
	static ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
	private static void scanSingleThread(File f)
	{
		//File f = new File("/Users");
		File[] subfiles = f.listFiles();
		
		if(subfiles==null) return;
		//String path = f.getAbsolutePath();
		for(int i=0;i<subfiles.length;i++)
		{
			final File subf = subfiles[i];
			//System.out.println(subf.length());
			
			if(!subf.isDirectory())
			{
				System.out.println(subf.getName());
			}else{
				Callable cal = new Callable() {
					public void run() {
						
					}

					@Override
					public Object call() throws Exception {
						// TODO Auto-generated method stub

						if (subf != null) {
							scanSingleThread(subf);
						}
						return null;
					}
				};
				
				Future fu = pool.submit(cal);
			}
		}
	}
}
