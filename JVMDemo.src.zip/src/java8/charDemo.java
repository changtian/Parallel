package java8;

import java.io.UnsupportedEncodingException;

public class charDemo {

	public static void main(String[] args) throws UnsupportedEncodingException {
		// TODO Auto-generated method stub
		String enc = System.getProperty("file.encoding");
		System.out.println("Encode: "+ enc);
		
		String a = "五五五五";
		byte[] buf1 = a.getBytes("unicode");
		byte[] gbkb= buf1;
		
		String gbkString = new String(gbkb, "gbk");
		
		System.out.println(gbkString);
		System.out.println("--------------unicode----------------");
		System.out.println("length: "+ buf1.length);
		for(int i=0; i<buf1.length;i++)
		{
			System.out.println(Integer.toHexString(buf1[i]));
		}
		
		buf1 = a.getBytes("gbk");
		System.out.println("--------------gbk----------------");
		System.out.println("length: "+ buf1.length);
		for(int i=0; i<buf1.length;i++)
		{
			System.out.println(Integer.toHexString(buf1[i]));
		}
		
		
		buf1 = a.getBytes("UTF-8");
		System.out.println("--------------UTF-8----------------");
		System.out.println("length: "+ buf1.length);
		for(int i=0; i<buf1.length;i++)
		{
			System.out.println(Integer.toHexString(buf1[i]));
		}
	}

}
