package java8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PipeStreamDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		PipedInputStream pis = new PipedInputStream();
		PipedOutputStream pos = new PipedOutputStream(pis);
		
		Sender sender = new Sender(pos);
		Reciever reciever = new Reciever(pis);
		ExecutorService executorService = Executors.newCachedThreadPool();
		executorService.execute(sender);
		executorService.execute(reciever);
	}
	
	static class Sender extends Thread{
		private PipedOutputStream pipedOutputStream;
		public Sender(PipedOutputStream pipedOutputStream)
		{
			this.pipedOutputStream = pipedOutputStream;
		}
		
		@Override
		public void run()
		{
			try {
	            FileInputStream fis = new FileInputStream("C:\\tmp\\logs\\GXSWPFLog.txt");
	            
	            byte[] buf = new byte[1024];
	            int len = 0;
	            while((len=fis.read(buf))!=-1){
	            	pipedOutputStream.write(buf, 0, len);
	            }
	            pipedOutputStream.flush();
	            pipedOutputStream.close();
	            fis.close();
	            
            } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
			
		}
	}
	
	static class Reciever extends Thread{
		
		private PipedInputStream pis;
		public Reciever(PipedInputStream pis)
		{
			this.pis = pis;
		}
		
		@Override
		public void run()
		{
			try {
	            FileOutputStream fos = new FileOutputStream("C:\\tmp\\logs\\output.txt");
	            byte[] buf = new byte[1024];
	            int len =0;
	            while((len=pis.read(buf))!=-1){
	            	fos.write(buf, 0, len);
	            }
	            
            } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
			
		}
	}

}
