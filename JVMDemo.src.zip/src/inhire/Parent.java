package inhire;

public class Parent {

	protected String name;
	
	public Parent()
	{
		System.out.println("Parent()");
	}
	
	public Parent(String name)
	{
		System.out.println("Parent(name)");
		this.name=name;
	}
	
	
	
}
