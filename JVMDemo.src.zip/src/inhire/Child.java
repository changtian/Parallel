package inhire;


public class Child extends Parent
{
	public Child()
	{
		System.out.println("Chiled()");
	}
	
	public Child(String name)
	{
		super(name);
		System.out.println("Chiled Name is: "+ this.name);
		System.out.println("Chiled(name)");
		
		this.name = "Child."+name;
		System.out.println("Chiled Name is: "+ this.name);
		
		System.out.println(Inner.Family);
		System.out.println(Inner.add);
	}
	
	public void run()
	{
		final int miles=100;
		class PartInner 
		{
			void run(){
			System.out.println(name + " is Running: "+ miles);//只能访问被final修饰的变量
			}
		}
		
		PartInner pi = new PartInner();
		pi.run();
		
		throw new RuntimeException();
		
	}
	
	static class Inner
	{
		static final String Family="Wu";
		static String add="SH";
	}

	public static void main(String[] args)
	{
		Child c = new Child();
		
		System.out.println();
		
		Child cn = new Child("Me");
		try{
		cn.run();
		}catch(Exception e)
		{
			Error error;
			System.out.println("Error is:"+ e);
		}
	}
	
}
