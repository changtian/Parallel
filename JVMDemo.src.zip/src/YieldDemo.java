import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class YieldDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t = new Thread(){
			int count = 0;
			long start = System.currentTimeMillis();
			@Override
			public void run() {
			    // TODO Auto-generated method stub
			    super.run();
			    while (true) {
			    	count ++;
			    	long time = System.currentTimeMillis() - start;
			    	System.out.println("Son run." + count + " time is: "+ time);
			    	if(time >=6000)
			    		break;
                }
			}
		};
		t.start();
		//t.sleep(10000);
		Lock lock = new ReentrantLock();
		
		
		while (true) {
			t.yield();
	        //System.out.println("Father run.");
        }
	}

}
