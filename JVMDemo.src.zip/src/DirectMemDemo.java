import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class DirectMemDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List data = new ArrayList();
		
		while(true)
		{
			ByteBuffer buf = ByteBuffer.allocateDirect(1024*1024);//1M
			
			data.add(buf);
			
		}
	}

}
