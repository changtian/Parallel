
public class Key {

	public Key(int position, int length) {
		// TODO Auto-generated constructor stub
	}
	private int position;
	private int length;
}
