
public class EscapAnaTest {

	static Object a=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start=System.currentTimeMillis();
		
		
		
		for(int i=0;i<100000000;i++)
		{
			Object o = new Object();
			String string= o.toString();
			a=i;
		}
		
		/*
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println(a.toString());
				
			}
		}).start();
		*/
		long after=System.currentTimeMillis();
		System.out.println(after-start);
		
	}

}
