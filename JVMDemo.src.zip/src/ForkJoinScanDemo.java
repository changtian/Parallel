import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;

public class ForkJoinScanDemo {

	public static volatile long taskNum = 0;
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		
		ForkJoinPool pool = new ForkJoinPool();//equal to cpu core num, 
		File root = new File("/Users");
		ScanTask task = new ScanTask(root);
		
		Future<String> f = pool.submit(task);//不阻塞
		
		
		if(f!=null)
		{
			System.out.println(f.get());//阻塞
		}
		
		
		long after = System.currentTimeMillis();
		System.out.println(after-start);
		System.out.println(taskNum);
		
		
		while(pool.getActiveThreadCount()>0)
		{
			Thread.yield();
		}
	}

}

class ScanTask extends RecursiveTask<String>
{
	private File path;
	public ScanTask(File path) {
		super();
		ForkJoinScanDemo.taskNum++;
		this.path = path;
	}
	private String result="";
	@Override
	protected String compute() {
		// TODO Auto-generated method stub
		
		
		if(path.isFile())
		{
			result = path.getName();
			System.out.println(result);
		}else
		{
			Collection<ScanTask> tasks = new ArrayList();
			if(path==null || path.listFiles()==null)
			{
				return "";
			}
			for(File sf:path.listFiles())
			{
				
				ScanTask subTask = new ScanTask(sf);
				tasks.add(subTask);
				invokeAll(tasks);
				//subTask.fork();
				//String j = subTask.join();//no need to join here, join makes it slow then single thred
				//if(j!=null)
				//{
				//result += j;
				//}
			}
		}
		
		return result;
	}}
