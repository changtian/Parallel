package designpattern.proxy;

public class ProxyWorker implements IWorker{

	IWorker worker;
	
	public ProxyWorker(IWorker worker)
	{
		this.worker = worker;
	}
	
	@Override
    public void work() {
	    // TODO Auto-generated method stub
	    this.worker.work();
    }

}
