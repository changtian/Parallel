package designpattern.proxy;

public class ConcreteWorker implements IWorker{

	@Override
    public void work() {
	    // TODO Auto-generated method stub
	    
    }

}
