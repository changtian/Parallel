package designpattern.proxy;

public interface IWorker {
	void work();
}
