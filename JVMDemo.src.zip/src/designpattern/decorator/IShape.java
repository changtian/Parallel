package designpattern.decorator;

public interface IShape {
	void draw();
}
