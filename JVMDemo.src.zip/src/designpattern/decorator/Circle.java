package designpattern.decorator;

public class Circle implements IShape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub

	}

}
