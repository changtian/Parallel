package designpattern.decorator;

public abstract class ShapeDecorator implements IShape{
	IShape shape;
}
