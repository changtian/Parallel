package designpattern.decorator;

public class CircleDecorator extends ShapeDecorator{

	IShape shape = new Circle();
	@Override
    public void draw() {
	    // TODO Auto-generated method stub
		//aditional works
	    shape.draw();
    }

}
