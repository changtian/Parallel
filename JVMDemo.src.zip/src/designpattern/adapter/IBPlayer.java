package designpattern.adapter;

public interface IBPlayer {
	void playB();
}
