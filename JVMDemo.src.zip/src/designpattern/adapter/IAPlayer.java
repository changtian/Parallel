package designpattern.adapter;

public interface IAPlayer {
	void play();
}
