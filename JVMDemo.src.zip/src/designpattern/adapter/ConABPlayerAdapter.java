package designpattern.adapter;

public class ConABPlayerAdapter implements IAPlayer{
	IBPlayer bPlayer;
	
	public ConABPlayerAdapter(IBPlayer bPlayer)
	{
		this.bPlayer=bPlayer;
	}
	
	@Override
    public void play() {
	    // TODO Auto-generated method stub
	    this.bPlayer.playB();
    }

}
