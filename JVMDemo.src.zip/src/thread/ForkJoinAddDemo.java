package thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ForkJoinAddDemo {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();

		ForkJoinPool pool = new ForkJoinPool();// equal to cpu core num,
		
		AddTask at = new AddTask(1, 10);
		int result = pool.invoke(at);
		result = at.get();
		System.out.println(result);
		System.out.println("Time: "+(System.currentTimeMillis()-start));
		
		
	}
	
static class AddTask extends RecursiveTask<Integer>{
	int from;
	int to;
	
	public AddTask(int from, int to)
	{
		this.from = from;
		this.to= to;
	}
	
	@Override
    protected Integer compute() {
	    // TODO Auto-generated method stub
		int result =0;
		System.out.println(from + "," + to);
		if(from == to)
		{
			result = from;
		}
		else if(to-from >=2)
	    {
	    	List<AddTask> subtasks =
	                new ArrayList<AddTask>();
	            subtasks.addAll(createSubtasks());
	            
	            for(AddTask st : subtasks)
	            {
	            	st.fork();
	            }
	            
	            for(AddTask st: subtasks)
	            {
	            	result+=st.join();
	            }
	    }else
	    {
	    	result = from+to;
	    }
        return result;
    }
	
	private List<AddTask> createSubtasks() {
        List<AddTask> subtasks =
        new ArrayList<AddTask>();

        AddTask left = new AddTask(from, (to+from-1)/2);
        AddTask right = new AddTask((to+from+1)/2, to);

        subtasks.add(left);
        subtasks.add(right);

        return subtasks;
    }
	
}

}
