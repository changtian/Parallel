package thread;

public class InterruptDemo {


	//how to stop thread properly.
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Thread t1 = new Thread() {
			@Override
			public void run() {
				try {
					//!isInterrupted(), won't catch InterruptedException
					while (true) {
						Thread.sleep(100);
						//sleep, join
						System.out.println("T1 is running....");
					}
					//System.out.println("Interrupted.");
				} catch (InterruptedException ex) {
					System.out.println(Thread.currentThread().getName() + Thread.currentThread().getState() + " catched InterruptedException.");
				}
			}
		};
		
		t1.setName("T1");
		
		Thread t2 = new Thread()
		{
			@Override
			public void run()
			{
				
				try{
					while (true) {
						//若线程选择忽略InterruptedException，则线程并不会被真正中断
	                    if(!isInterrupted())
	                    {
	                    	System.out.println("T2 is running");
	                    }else
	                    {
	                    	throw new InterruptedException();
	                    }
	                    
                    }
				}
				catch(InterruptedException ex)
				{
					System.out.println(Thread.currentThread().getName() + Thread.currentThread().getState() + " catched InterruptedException.");
				}
			}
		};
		t2.setName("T2");
		
		t2.start();
		t1.start();
		Thread.sleep(10000);
		t1.interrupt();
		
		t2.interrupt();
		System.out.println("Exit.");

	}

}
