package thread;

import java.util.concurrent.locks.ReentrantLock;

public class DeadLockDemo {

	public static String obj1 = "obj1";
	public static String obj2 = "obj2";
	
	static class Lock1 implements Runnable{

		@Override
        public void run() {
	        // TODO Auto-generated method stub
	        try{
	        	
	        	ReentrantLock lock = new ReentrantLock();
	        	System.out.println("Lock1 starts.");
	        	while(true)
	        	{
	        		synchronized (DeadLockDemo.obj1) {
	                    System.out.println("Lock1 locks ojb1");
	                    Thread.sleep(3000);
	                    synchronized (DeadLockDemo.obj2) {
	                        System.out.println("Lock1 locks obj2");
	                        System.out.println("Lock1 running.");
                        }
                    }
	        	}
	        }catch(InterruptedException ex)
	        {
	        	ex.printStackTrace();
	        }
        }
		
	}
	
	static class Lock2 implements Runnable{

		@Override
        public void run() {
	        // TODO Auto-generated method stub
	        try{
	        	System.out.println("Lock2 starts.");
	        	while(true)
	        	{
	        		synchronized (DeadLockDemo.obj2) {
	                    System.out.println("Lock2 locks ojb2");
	                    Thread.sleep(3000);
	                    synchronized (DeadLockDemo.obj1) {
	                        System.out.println("Lock2 locks obj1");
	                        System.out.println("Lock2 running.");
                        }
                    }
	        	}
	        }catch(InterruptedException ex)
	        {
	        	ex.printStackTrace();
	        }
        }
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread a = new Thread(new Lock1());
        Thread b = new Thread(new Lock2());
        a.start();
        b.start();
        
        while(true)
        {
        	Thread.yield();
        }
	}

}
