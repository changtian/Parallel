package thread;

import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableRunnableDemo {

	public static void main(String[] args) {
		//TestCallable();
		
		TestRunnable();
	}

	private static void TestCallable() {
	    // TODO Auto-generated method stub
		ExecutorService exec = Executors.newFixedThreadPool(10);
		ArrayList<Future<String>> results = new ArrayList<Future<String>>();
		
		for(int i=0; i<10; i++)
		{
			String email = "asd"+i+"@qq.com";
			results.add(exec.submit(new TaskWithResult(email)));
		}
		
		boolean isDone = false;
		while(!isDone)
		{
			isDone = true;
			for(Future<String> future:results)
			{
				if(!future.isDone())
				{
					isDone = false;
					try{
						Thread.sleep(1000);
					}catch(InterruptedException e)
					{
						
					}
					
					break;
				}
			}
			
			exec.shutdown();
		}
    }
	
	private static void TestRunnable()
	{
		/*System.out.println("main线程调用runnable");
		RunnableDemo lauch = new RunnableDemo();
		lauch.run();
		System.out.println();
		System.out.println("********************************");
		
		System.out.println("在新线程中启动任务");
		Thread thread = new Thread(new RunnableDemo());
		thread.start();
		System.out.println("Waiting for LiftOff");
		System.out.println("********************************");
		
		System.out.println("添加多个线程去驱动更多的任务");
		for(int i=0; i<5; i++)
		{
			new Thread(new RunnableDemo()).start();
		}
		System.out.println("Waiting for LiftOff");*/
		
		ExecutorService exec = Executors.newCachedThreadPool();
		exec= Executors.newFixedThreadPool(5);
		
		for(int i=0; i<5; i++)
		{
			exec.execute(new RunnableDemo());
		}
		exec.shutdown();
	}
	
}

class TaskWithResult implements Callable<String>{

	private String email;
	
	public TaskWithResult(String email)
	{
		this.email = email;
	}
	
	@Override
    public String call() throws Exception {
		System.out.println(email);
        return null;
    }
	
}

class RunnableDemo implements Runnable
{
	protected int countDown = 10;
	private static int taskCount = 10;
	private final int id = taskCount++;
	
	public RunnableDemo()
	{}
	
	public String statu()
	{
		return "#"+id+"("+(countDown>0?countDown:"LiftOff!")+").";
	}
	
    public void run() {
	    // TODO Auto-generated method stub
	    while (countDown -->0) {
	        System.out.print(statu());
	        Thread.yield();
        }
    }
	
}
