package thread;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadLocalDemo {

	static ThreadLocal<SimpleDateFormat> localFormat = new ThreadLocal<SimpleDateFormat>() {
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		}
	};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 5; i++) {
			final Thread t = new Thread() {
				@Override
				public void run() {
					System.out.println("当前线程:" + Thread.currentThread().getName() + ",已分配ID:" + ThreadId.get());
				}
			};
			t.start();
		}

		for (int i = 0; i < 5; i++) {
			Thread t = new Thread(new FieldThread(i));
			t.start();
		}

		/**
		 * Jetty 同一个controller 有不同的 handle 方法，每一个请求都会有一个线程去处理，但是SimpleDateFormat是controller中写的static 变量
		 */
		for (int i = 0; i < 5; i++) {
			final int inputI = i;
			Thread t = new Thread() {
				@Override
				public void run() {
					SimpleDateFormat format = localFormat.get();
					if (inputI / 2 == 0) {
						format = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
					}
					System.out.println("当前线程:" + inputI +"输出: " + format.format(new Date()));
					;
				}
			};
			t.start();
		}
	}

	static class ThreadId {
		private static final AtomicInteger nextId = new AtomicInteger(0);

		private static final ThreadLocal<Integer> threadId = new ThreadLocal<Integer>() {
			protected Integer initialValue() {
				return nextId.getAndIncrement();
			}
		};

		public static int get() {
			return threadId.get();
		}
	}

	static class FieldThread implements Runnable {

		private int id = 0;

		public FieldThread(int i) {
			id = i;
		}

		public int getId() {
			return id;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("My id is: " + getId());
		}

	}
}
