package thread;

import java.util.concurrent.Semaphore;

public class SemophoreDemo {

	static class Customer implements Runnable{
		private String name;
		private Semaphore seats;
		
		public Customer(String name, Semaphore seats)
		{
			this.name = name;
			this.seats = seats;
		}
		
		@Override
        public void run() {
	        // TODO Auto-generated method stub
	        try{
	        	seats.acquire();
	        	System.out.println(name + " begin transaction.");
	        	Thread.sleep(10000);
	        	System.out.println(name + " finished transaction.");
	        	seats.release();
	        }catch(Exception ex)
	        {
	        	ex.printStackTrace();
	        }
        }
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Semaphore seats = new Semaphore(5);
	        for(int i=0;i<10;i++)
	        {
	        	Thread t = new Thread(new Customer(String.valueOf(i), seats));
	        	t.start();
	        }
	        
        while(true)
        {
        	Thread.yield();
        }
	}

}
