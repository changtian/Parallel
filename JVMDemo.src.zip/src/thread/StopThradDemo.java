package thread;

public class StopThradDemo {

	public static void main(String[] args) throws InterruptedException {
		StopThread thread = new StopThread();
	    thread.setName("StopThread");
	    
	    thread.start();
	    
	    Thread.sleep(1000);
	    
	    thread.cancel();
	    
	    
	    
	    while (true) {
	        Thread.yield();
        }
		
    }
	
	public static class StopThread extends Thread
	{
		@Override
		public void run()
		{
			while(!cancelled)
			{
				System.out.println("RUNNING. waited "+ System.currentTimeMillis());
				try {
	                Thread.sleep(20000);
                } catch (InterruptedException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
                }
			}
			
			System.out.println("Exit, waited "+ (System.currentTimeMillis() - start));
		}
		
		private volatile boolean cancelled = false;
		private long start;
		public void cancel()
		{
			start = System.currentTimeMillis();
			System.out.println("Cancel at: " + start);
			cancelled = true;
		}
	}
	
}


