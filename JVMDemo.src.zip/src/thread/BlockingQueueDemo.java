package thread;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class BlockingQueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final BlockingQueue<Integer> que = new LinkedBlockingDeque<>(10);
		ScheduledExecutorService pool = Executors.newScheduledThreadPool(1);
		final Random random = new Random();
		pool.scheduleAtFixedRate(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				que.offer(random.nextInt(101));
			}
		}, 0, 200, TimeUnit.MILLISECONDS);
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true)
				{
					try{
						Thread.sleep(2000);
						System.out.println("开始取值。");
						List<Integer> list = new LinkedList<>();
						
						que.drainTo(list);
						for (Integer integer : list) {
	                        System.out.println(integer);
                        }
						
					}catch(InterruptedException e)
					{
						Collection c;
						Set set;
					}
				}
			}
		}).start();
	}
}
