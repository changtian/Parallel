package thread;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveAction;
import java.util.regex.Pattern;

public class ForkJoinScanDemo {

	public static volatile long taskNum = 0;

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();

		ForkJoinPool pool = new ForkJoinPool();// equal to cpu core num,
		File root = new File("C:\\XP\\kafka producer monitor");
		ScanTask task = new ScanTask(root);

		Future f = pool.submit(task);// 不阻塞

		if (f != null) {
			// System.out.println(f.get());// 阻塞
		}

		long after = System.currentTimeMillis();

		while (pool.getActiveThreadCount() > 0) {
			Thread.yield();
		}

		System.out.println(after - start);
		// System.out.println(taskNum);
	}

}

class ScanTask extends RecursiveAction {
	private File path;

	public ScanTask(File path) {
		super();
		ForkJoinScanDemo.taskNum++;
		this.path = path;
	}

	private String result = "";

	protected void compute() {
		// TODO Auto-generated method stub

		if (path.isFile()) {
			result = path.getName();

			boolean isValid = false;
			String pattern = "*txt_*.*";

			try {
				Pattern p = Pattern.compile("_[\\s\\S]+\\.");
				java.util.regex.Matcher m = p.matcher(result);
				isValid = m.find();
				
				
				if(isValid)
				{
					System.out.println(result);
					String newString = m.replaceAll(".");
					System.out.println(newString);
					
					String folder = path.getParent();
					Path allNewPath =  Paths.get(folder, newString);
					
					File newFile = new File(allNewPath.toString());
					path.renameTo(newFile);
					
				}
			} catch (Exception ex) {

			}
			//

			//
			// Pattern.matches(pattern, result);
			if (isValid) {
				System.out.println(result);
			}
		} else {
			Collection<ScanTask> tasks = new ArrayList();
			if (path != null && path.listFiles() != null) {

				for (File sf : path.listFiles()) {

					ScanTask subTask = new ScanTask(sf);
					tasks.add(subTask);
					// subTask.join();
					// subTask.get();
					// subTask.fork();
					// invokeAll(tasks);
					// subTask.fork();
					// String j = subTask.join();//no need to join here, join makes it slow then single thred
					// if(j!=null)
					// {
					// result += j;
					// }
				}

				for (ScanTask st : tasks) {
					st.fork();
				}

			}
		}
	}
}
