package oom;

/**
 * -Xss2M
 * @author gw67412
 *
 */
public class StackOOM {

	int i =0;
	private void dontStop()
	{
		while(true){
			
		}
	}
	
	public void stackLeakByThread()
	{
		while(true){
			Thread thread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// 
					dontStop();
				}
			});
			i++;
			thread.start();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackOOM oom = new StackOOM();
		try{
			oom.stackLeakByThread();
		}catch(Throwable e)
		{
			System.out.println("Thread num: "+ oom.i);
			throw e;
		}
	}
	
	/**
	 * Exception in thread "main" java.lang.OutOfMemoryError: unable to create new native thread
	at java.lang.Thread.start0(Native Method)
	at java.lang.Thread.start(Thread.java:713)
	at oom.StackOOM.stackLeakByThread(StackOOM.java:30)
	at oom.StackOOM.main(StackOOM.java:38)
Thread num: 522

	 */

}
