package oom;

import java.util.ArrayList;
import java.util.List;

/**
 * -XX:PermSize=1M -XX:MaxPermSize=1M
 * Error occurred during initialization of VM
 * Too small initial permanent heap
 * -XX:PermSize=10M -XX:MaxPermSize=10M
 * @author gw67412
 *
 */
public class RuntimeConstantPoolOOM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		int i = 0; 
        while (true) {
        	String string = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"+ i++;
            list.add(string.intern());
        }
	}
	
	/**
	 * Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
	at java.util.Arrays.copyOfRange(Arrays.java:2694)
	at java.lang.String.<init>(String.java:203)
	at java.lang.StringBuilder.toString(StringBuilder.java:405)
	at oom.RuntimeConstantPoolOOM.main(RuntimeConstantPoolOOM.java:21)
	 */

}
