package memory;

//-XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintReferenceGC (-XX:+UseG1GC)
//-XX:+PrintAdaptiveSizePolicy -XX:+UnlockExperimentalVMOptions -XX:+G1ReclaimDeadHumongousObjectsAtYoungGC 
//-XX:G1LogLevel=finest -XX:+G1TraceReclaimDeadHumongousObjectsAtYoungGC
//-XX:G1HeapRegionSize=1
public class G1Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte[] hugeByte = new byte[1024*1024*5];
		
		while (true) {
	        Thread.yield();
        }
	}

}
