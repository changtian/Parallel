package memory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 *  -Xmn10m -Xms25m -Xmx25m -XX:OldSize=10485760 -XX:+UseParNewGC
 *  
 */
public class OldSize {

    public static void main(String[] args) {
    	String[] a = {"a", "b", "c"};
        ArrayList<String> sList = new ArrayList<>(Arrays.asList(a));
    	
        Iterator<String> sIterator = sList.iterator();
        while (sIterator.hasNext()) {
        	String b= sIterator.next();
	        sIterator.remove();
	        
        }
    	
        System.out.println(sList);
        
    }
    
}
