
public class JITDemo {
	public static void main(String[] args)
	{
		System.out.println("test");
		for(int i=0; i<10000; i++)
		{
			test();
		}
		stackOverflowTest();
	}
	
	private static void test()
	{
		
	}
	
	static int count = 1;
	private static void stackOverflowTest()
	{
		count++;
		stackOverflowTest();
	}
	
	
	
}
