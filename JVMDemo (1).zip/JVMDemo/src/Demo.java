
public class Demo {
	
	public static void main(String[] args)
	{
	
	long before = System.currentTimeMillis();
	a();
	long after = System.currentTimeMillis();
	
	System.out.println(before-after);
	}
	
	private static void a()
	{
		int val=1;
		for(int index=0; index<100000000; index+=1){
			val+=20;
			val/=3;
		}
		//jdk1.8 没做这个优化， 哈？
		//System.out.println(val);
	}

}
