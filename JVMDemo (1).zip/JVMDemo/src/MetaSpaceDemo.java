
import net.sf.cglib.proxy.Enhancer;

public class MetaSpaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Enhancer e = new Enhancer();
		//only full GC can clean MetaSpace(Perm gen), it's one triger of full GC
		//after 1.8, there's no Perm Gen
		//OoO meta space/ Perm Gen
	}

}
