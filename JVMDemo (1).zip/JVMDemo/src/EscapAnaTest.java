
public class EscapAnaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start=System.currentTimeMillis();
		Object a;
		for(int i=0;i<100000000;i++)
		{
			Object o = new Object();
			a=o;
		}
		long after=System.currentTimeMillis();
		System.out.println(after-start);
		
	}

}
