
public class HeapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		while(true){
		byte[] buf = new byte[1024*1024];
		//big object move to old gen
		}
	}

}
