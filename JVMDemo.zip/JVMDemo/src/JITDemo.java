
public class JITDemo {
	public static void main(String[] args) {
	    long start = System.currentTimeMillis();
	    a();
	    long end = System.currentTimeMillis();
	    System.out.println(end-start);
    }
	
	public static void a()
	{
		int val=1;
		for(int i=0;i<1000000000; i++)
		{
			val+=20;
			val/=3;
		}
		//System.out.println(val);
	}
}
