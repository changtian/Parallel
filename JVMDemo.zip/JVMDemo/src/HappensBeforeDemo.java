
public class HappensBeforeDemo {

	static int a, b, x, y;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		while (true) {
	        a=b=x=y=0;
	        Thread t1= new Thread(){
	        	public void run()
	        	{
	        		a = 1; 
	        		x = b;
	        	}
	        };
	        Thread t2 = new Thread(){
	        	public void run()
	        	{
	        		b=1;
	        		y=a;
	        	}
	        };
	        
	        t1.start();t2.start();
	        t1.join();t2.join();
	        
	        System.out.println("(" + x + "," + y + ")");
	        //possilbe output: (0,1), (1,0), (1,1)
	        //&& (0,0);
	        //https://www.cnblogs.com/chenyangyao/p/5269622.html
	        
	        if(x==0 && y==0)
	        {
	        	System.out.println(x+":"+y);
	        	break;
	        }
        }

		
		System.out.println("Exit.");
	}

}
