package oom;

/**
 * 栈异常
 * 如果线程请求的栈深度大于虚拟机所允许的最大深度，将抛出StackOverflowError
 * 如果虚拟机在扩展栈时无法申请到足够的内存空间，将抛出OutOfMemoryError
 * VM Args：-Xss128k
 * 默认情况下，即不加Xss限制，输出的length为8956，加了Xss128k length位2403
 * @author gw67412
 *
 */
public class StackSOF {

	private int stackLength = 1;
	public void stackLeak()
	{
		stackLength++;
		stackLeak();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StackSOF sof = new StackSOF();
		try{
			sof.stackLeak();
		}catch(Throwable e)
		{
			System.out.println("stack length: "+ sof.stackLength);
			throw e;
		}
	}
/**
 * stack length: 2300
Exception in thread "main" java.lang.StackOverflowError
	at oom.StackSOF.stackLeak(StackSOF.java:17)
	at oom.StackSOF.stackLeak(StackSOF.java:18)
	at oom.StackSOF.stackLeak(StackSOF.java:18)
	at oom.StackSOF.stackLeak(StackSOF.java:18)
 */
}
