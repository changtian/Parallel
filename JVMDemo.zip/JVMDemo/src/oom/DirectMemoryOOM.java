package oom;

import java.lang.reflect.Field;
import java.nio.ByteBuffer;

import sun.misc.Unsafe;

/**
 * -Xmx20M -XX:MaxDirectMemorySize=10M
 * @author gw67412
 *
 */
public class DirectMemoryOOM {

	private static final int _1MB = 1024 * 1024*100;
	public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException {
		// TODO Auto-generated method stub
		Field unsafeField = Unsafe.class.getDeclaredFields()[0];
        unsafeField.setAccessible(true);
        //Unsafe unsafe = (Unsafe) unsafeField.get(null);
        int count = 0;
        while (true) {
        	count ++;
            //unsafe.allocateMemory(_1MB);
        	
        	ByteBuffer buf = ByteBuffer.allocateDirect(_1MB);//1M
        	
            System.out.println(count);
        }
	}
/**
 * Exception in thread "main" java.lang.OutOfMemoryError: Direct buffer memory
        at java.nio.Bits.reserveMemory(Bits.java:658)
        at java.nio.DirectByteBuffer.<init>(DirectByteBuffer.java:123)
        at java.nio.ByteBuffer.allocateDirect(ByteBuffer.java:306)
		at oom.DirectMemoryOOM.main(DirectMemoryOOM.java:26)
 */
}
