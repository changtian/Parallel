package thread;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierDemo {

	static class Friend implements Runnable{

		private int id=0;
		private CyclicBarrier cb;
		
		public Friend(CyclicBarrier cb, int id)
		{
			this.id= id;
			this.cb = cb;
		}
		
		
		@Override
        public void run() {
	        // TODO Auto-generated method stub
	        try{
	        	System.out.println(id + " on the way.");
	        	Thread.sleep(1000);
	        	System.out.println(id + " arrived.");
	        	cb.await();
	        }catch(InterruptedException | BrokenBarrierException exception)
	        {
	        	exception.printStackTrace();
	        }
        }
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CyclicBarrier cb = new CyclicBarrier(10, new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.print("All friends arrived, party begin.");
			}
		});
		
		for(int i=0; i<10; i++)
		{
			new Thread(new Friend(cb, i)).start();
		}
	}

}
