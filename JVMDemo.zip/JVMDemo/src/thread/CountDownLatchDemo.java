package thread;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

public class CountDownLatchDemo {

	static class Competitor implements Comparable<Competitor>, Runnable {
		private CountDownLatch jLatch;
		private CountDownLatch cLatch;
		private int score = 0;
		private String name = "";

		public Competitor(CountDownLatch jLatch, CountDownLatch cLatch, String name) {
			this.jLatch = jLatch;
			this.cLatch = cLatch;
			this.name = name;
		}

		public int getScore() {
			return score;
		}

		public void setScore(int score) {
			this.score = score;
		}

		@Override
        public int compareTo(Competitor o) {
	        // TODO Auto-generated method stub
			if(this.getScore() == o.getScore())
	        return 0;
			else if(this.getScore()>o.getScore())
				return -1;
			else 
				return 1;
        }

		@Override
        public void run() {
	        // TODO Auto-generated method stub
			try {
				System.out.println(name + " waiting for Judge command.");
				jLatch.await();
				System.out.println(name + " starts.");
				Thread.sleep(new Random().nextInt(5) * 1000);
				System.out.println(name + " finished.");
				cLatch.countDown();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
        }

		
	}

	static class Judge implements Runnable {
		private List<Competitor> competitors = new LinkedList<Competitor>();
		private CountDownLatch jLatch;
		private CountDownLatch cLatch;

		public Judge(CountDownLatch jLatch, CountDownLatch cLatch) {
			this.jLatch = jLatch;
			this.cLatch = cLatch;
		}

		@Override
		public void run() {

			try {// TODO Auto-generated method stub
				System.out.println("Judge command: Competion starts.");
				jLatch.countDown();
				System.out.println("Judge waits competitors.");
				cLatch.await();
				System.out.println("Judge starts score.");
				for (Competitor c : competitors) {
					c.setScore(new Random().nextInt());
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Collections.sort(competitors);
			// Collections.sort(competitors);
		}

		public void Add(Competitor c) {
			this.competitors.add(c);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final CountDownLatch jLatch = new CountDownLatch(1);
		final CountDownLatch cLatch = new CountDownLatch(5);
		
		Judge judge = new Judge(jLatch, cLatch);
		Thread judgeThread = new Thread(judge);
		
		
		for(int i=0;i<5;i++)
		{
			Competitor competitor = new Competitor(jLatch, cLatch, "Competitor_"+ String.valueOf(i));
			judge.Add(competitor);
			Thread competionThread = new Thread(competitor);
			competionThread.start();
			
		}
		
		judgeThread.start();
		
			
		
		
		
	}

}
