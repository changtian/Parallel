package thread;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ThreadSafe
 * @author gw67412
 *
 */
public class SynchDemo extends Thread{
	int i = 0;
	Integer in = 0;
	// synchronized
	// synchronized(in)
	Lock lock = new ReentrantLock();

	// lock.lock();
	// lock.unlock();
	public void increase()
	{
		lock.lock();
		i++;
		i++;
		lock.unlock();
	}

	public int getValue() {
		
		return i;
	}
	
	@Override
	public void run()
	{
		while (true) {
			lock.lock();
			int val = getValue();
			lock.unlock();
			if (val % 2 != 0) {
				System.out.println(val);
				System.exit(0);
			}
			System.out.println(val);
		}
	}

	public static void main(String[] args) {
		final SynchDemo tt = new SynchDemo();
		tt.start();
		while (true) {
			tt.increase();
		}
	}
}
