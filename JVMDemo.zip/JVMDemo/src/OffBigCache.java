import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;

public class OffBigCache {
	private ByteBuffer cache = ByteBuffer.allocateDirect(10*1024*1024);
	private int position;
	public Key put(java.io.Serializable obj) throws IOException
	{
		byte[] buff;
		ByteArrayOutputStream o = new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(o);
		out.writeObject(obj);
		buff = o.toByteArray();
		cache.put(buff);
		
		Key key= new Key(position, buff.length);
		return key;
	}
	
	public Object get(Key key)
	{}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
