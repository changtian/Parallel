package memory;

/**
 *  -Xmn10m -Xms25m -Xmx25m -XX:OldSize=10485760 -XX:+UseParNewGC
 *  
 */
public class OldSize {

    public static void main(String[] args) {
        
        while(true) {
            Thread.yield();
        }
    }
    
}
