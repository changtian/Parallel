import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

import org.omg.CORBA.PUBLIC_MEMBER;


public class MultipleThreadDemo {

	public void test() throws InterruptedException, ExecutionException
	{
		Thread t1 = new ThreadExt();
		Thread t2 = new Thread(new ThreadRun());
		
		FutureTask<String> fTask = new FutureTask<>(new ThreadCall());
		Thread t3 = new Thread(fTask);
		t3.start();
		fTask.get();
	}
	
	public static void main(String[] args) {
		
	}
	
	class ThreadExt extends Thread{
		@Override
		public void run()
		{
			
		}
	}
	
	class ThreadRun implements Runnable
	{

		@Override
        public void run() {
	        // TODO Auto-generated method stub
	        
        }
		
	}
	
	class ThreadCall implements Callable<String>{

		@Override
        public String call() throws Exception {
	        // TODO Auto-generated method stub
	        return null;
        }
		
	}

}
