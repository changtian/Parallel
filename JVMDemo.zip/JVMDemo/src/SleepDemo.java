
public class SleepDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Thread t = new Thread(){
			int count = 0;
			long start = System.currentTimeMillis();
			@Override
			public void run() {
			    // TODO Auto-generated method stub
			    super.run();
			    while (true) {
			    	count ++;
			    	long time = System.currentTimeMillis() - start;
			    	System.out.println("Son run." + count + " time is: "+ time);
			    	if(time >=6000)
			    		break;
                }
			}
			
		};
		t.start();
		t.sleep(10000);
		//sleep, wait, joint 
		
		while (true) {
			//t.yield();
	        System.out.println("Father run.");
        }
	}

}
