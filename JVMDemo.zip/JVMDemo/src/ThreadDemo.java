import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadDemo {
	static ExecutorService pool = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		
		
		Callable<Integer> cal = new Callable<Integer>(){
			public Integer call() throws Exception{
				return 5050;
			}
		};
		
		Future<Integer> f = pool.submit(cal);
		System.out.println(f.get());
		pool.shutdown();
		
		
		// TODO Auto-generated method stub
		Thread t1 = new Thread(){
			public void run()
			{
				while(true)
				{
					//Thread.yield() t2执行的机会多
					System.out.println(getId() + " is running.");
				}
			};
		};
		Thread t2 = new Thread(){
			public void run()
			{
				while(!start)
				{
					System.out.println(getId() + " is running.");
				}
				
				while(!isInterrupted())
				{
					try{
						System.out.println("");
						Thread.sleep(10000);
						
					}catch(Exception ex)//InterruptException
					{
						return;
					}
				}
			};
		};
		
		
		
		t1.start();
		t2.start();
		t1.sleep(1000);//main thread will sleep
		Thread.sleep(10000);
		t1.yield(); Thread.yield();//让渡执行机会，执行机会少，但还是会执行
		System.out.println("main thread. ");
		
		//t1, t2加塞，主线程没机会执行了，但是2不会加塞1 只会加塞 join 执行所在到线程 
		//stop强行杀死线程，无条件释放锁，不安全
		//suspend 不释放锁，不安全
		//怎么停。 boolean stop = true. 共享数据，对于t1, t2并不可见， 加volatile
		
		t1.interrupt();
		
		t1.join();
		t2.join();
		
		//自旋锁
		while(true)
		{
			//执行100次之后自动切换到锁。综合两种锁到优势
			Thread.yield();
		}
	}
	
	//
	
	static volatile boolean start =false;

}
