import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.RecursiveTask;


public class ForkJoinPoolDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ForkJoinPool fjp = new ForkJoinPool(Runtime.getRuntime().availableProcessors());
		
		RecursiveAction action = new ScanAction();
		
		RecursiveTask<String> task = new ScanTask();
		
		fjp.submit(action);
		fjp.submit(task);
	}
	
	static class ScanAction extends RecursiveAction{

		@Override
        protected void compute() {
	        // TODO Auto-generated method stub
	        
        }
		
	}
	
	static class ScanTask extends RecursiveTask<String>{

		@Override
        protected String compute() {
	        // TODO Auto-generated method stub
	        return null;
        }
		
	}

}
