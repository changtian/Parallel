﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class Vertex
    {
        public string Data;
        public bool IsVisited;
        public Vertex(string data)
        {
            this.Data = data;
        }
    }
}
