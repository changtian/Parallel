﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class Graph
    {
        private const int Number = 10;
        private Vertex[] vertiexes;
        public int[,] adjmatrix;
        int numVerts = 0;

        public Graph()
        {
            adjmatrix = new Int32[Number, Number];
            vertiexes = new Vertex[Number];

            for (int i = 0; i < Number; i++)
            {
                for (int j = 0; j < Number; j++)
                {
                    adjmatrix[i, j] = 0;
                }
            }
        }

        public void AddVertex(string v)
        {
            vertiexes[numVerts] = new Vertex(v);
            numVerts++;
        }

        public void AddEdge(int vertex1, int vertex2)
        {
            adjmatrix[vertex1, vertex2] = 1;
        }

        public void DisplayVert(int vertexPosition)
        {
            Console.WriteLine(vertiexes[vertexPosition] + "");
        }

        public int FindNoSuccessor()
        {
            bool isEdge;
            for (int i = 0; i < numVerts; i++)
            {
                isEdge = false;
                for (int j = 0; j < numVerts; j++)
                {
                    if (adjmatrix[i, j] == 1)
                    {
                        isEdge = true;
                        break;
                    }
                }
                if (!isEdge)
                {
                    return i;
                }
            }
            return -1;
        }

        private void DelVertex(int vert)
        {
            if (vert <= numVerts - 1)
            {
                for (int i = vert; i < numVerts; i++)
                {
                    vertiexes[i] = vertiexes[i + 1];
                }

                for (int j = vert; j < numVerts; j++)
                {
                    MoveRow(j, numVerts);
                }

                for (int k = vert; k < numVerts - 1; k++)
                {
                    MoveCol(k, numVerts - 1);
                }

                numVerts--;
            }
        }

        private void MoveRow(int row, int length)
        {
            for (int col = row; col < numVerts; col++)
            {
                adjmatrix[row, col] = adjmatrix[row + 1, col];
            }
        }

        private void MoveCol(int col, int length)
        {
            for (int row = col; row < numVerts; row++)
            {
                adjmatrix[row, col] = adjmatrix[row, col + 1];
            }
        }

        public void TopSort()
        {
            int origVerts = numVerts;
            //存放返回节点的栈
            System.Collections.Stack result = new Stack();
            while (numVerts > 0)
            {
                //找到第一个没有后继节点的节点
                int currVertex = FindNoSuccessor();
                if (currVertex == -1)
                {
                    Console.WriteLine("图为环路图，不能搞拓扑排序");
                    return;
                }
                //如果找到，将其加入返回结果栈
                result.Push(vertiexes[currVertex].Data);
                //然后删除此节点
                DelVertex(currVertex);
            }
            /*输出排序后的结果*/
            Console.Write("拓扑排序的顺序为:");
            while (result.Count > 0)
            {
                Console.Write(result.Pop() + "");
            }
            /*输出排序后的结果*/
        }

        private int GetAdjUnvisitedVertex(int v)
        {
            for (int j = 0; j < numVerts; j++)
            {
                if (adjmatrix[v, j] == 1 && vertiexes[j].IsVisited == false)
                {
                    return j;
                }
            }
            return -1;
        }

        public void DepthFirstSearch()
        {
            //声明一个存储临时结果的栈
            System.Collections.Stack s = new Stack();
            //先访问第一个节点
            vertiexes[0].IsVisited = true;
            DisplayVert(0);
            s.Push(0);
            int v;

            while (s.Count > 0)
            {
                //获得和当前节点连接的未访问过节点的序号
                v = GetAdjUnvisitedVertex((int)s.Peek());
                if (v == -1)
                {
                    s.Pop();
                }
                else
                {
                    //标记为已经被访问过
                    vertiexes[v].IsVisited = true;
                    DisplayVert(v);
                    s.Push(v);
                }
            }
            //重置所有节点为未访问过
            for (int u = 0; u < numVerts; u++)
            {
                vertiexes[u].IsVisited = false;
            }


        }

        public void BreadthFirstSearch()
        {
            System.Collections.Queue q = new Queue();
            /*首先访问第一个节点*/
            vertiexes[0].IsVisited = true;
            DisplayVert(0);
            q.Enqueue(0);
            /*第一个节点访问结束*/
            int vert1, vert2;
            while (q.Count > 0)
            {
                /*首先访问同层级第一个节点*/
                vert1 = (int)q.Dequeue();
                vert2 = GetAdjUnvisitedVertex(vert1);
                /*结束*/
                while (vert2 != -1)
                {
                    /*首先访问第二个节点*/
                    vertiexes[vert2].IsVisited = true;
                    DisplayVert(vert2);
                    q.Enqueue(vert2);
                    //寻找邻接的
                    vert2 = GetAdjUnvisitedVertex(vert1);
                }
            }
            //重置所有节点为未访问过
            for (int u = 0; u < numVerts; u++)
            {
                vertiexes[u].IsVisited = false;
            }
        }

    }
}
