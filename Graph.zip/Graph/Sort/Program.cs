﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sort
{
    class Program
    {
        static void Main(string[] args)
        {

            Random random = new Random();




            int[] a = new int[] { 2, 3, 100, 6, 7, 99, 92, 4, 666, 99 };
            List<Int32> toSort = new List<Int32>(a);
            for (int i = 0; i < 100000; i++)
            {
                int j = random.Next(500000);
                if (!toSort.Contains(j))
                {
                    toSort.Add(j);
                }
            }
           
            /*
            toSort.Add(5);
            toSort.Add(7);
            toSort.Add(2);
            toSort.Add(1);
            toSort.Add(9);
             */

            BubbleSort<Int32> sort = new BubbleSort<Int32>();
            //var result = sort.SortCorrect(toSort);

            //sort.SortCorrect(toSort);
            DateTime dt1 = System.DateTime.Now;
            Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();
            InsertSort<Int32> isort = new InsertSort<int>();
            //var result = sort.Sort(toSort);
            sort.SortCorrect(toSort);

            TimeSpan t1 = DateTime.Now.Subtract(dt1);
            Console.WriteLine("TimeSpan: " + t1.TotalMilliseconds);
            sw.Stop();
            t1 = sw.Elapsed;
            Console.WriteLine("TimeSpan: " + t1.TotalMilliseconds);

            Console.ReadKey();

        }
    }
}
