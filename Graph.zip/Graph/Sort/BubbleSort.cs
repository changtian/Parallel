﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sort
{
    class BubbleSort<T>: ISort<T> where T:IComparable
    {
        public IList<T> Sort(IList<T> toSort)
        {
            List<T> local = toSort.ToList();
            int countDown = toSort.Count;


            while (countDown>0)
            {
                int currentIndex = 0;
                IComparable a = local[currentIndex];
                
                for (int i = 0; i < local.Count; i++)
                {
                    IComparable b = local[i];
                    if (b.CompareTo(a) == 0)
                        continue;
                    if (b.CompareTo(a) > 0)
                    {
                        a = b;
                        
                    }
                    else
                    {
                        toSort[i] = (T)a;
                        toSort[currentIndex] = (T)b;
                    }
                    currentIndex = i;
                }
                countDown--;
                local = toSort.ToList();
            }

            return toSort;

        }

        public IList<T> SortCorrect(IList<T> toSort)
        {
            for (int j = 0; j < toSort.Count; j++)
            {
                for (int i = 0; i < toSort.Count - 1; i++)
                {
                    if (toSort[i].CompareTo(toSort[i + 1]) > 0)
                    {
                        var temp = toSort[i];
                        toSort[i] = toSort[i + 1];
                        toSort[i + 1] = temp;
                    }
                }
            }

            return toSort;
        }
    }
}
