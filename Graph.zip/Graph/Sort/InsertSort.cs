﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sort
{
    class InsertSort<T>: ISort<T> where T: IComparable
    {
        public IList<T> Sort(IList<T> toSort)
        {
            LinkedList<T> result = new LinkedList<T>();
            
            foreach (var item in toSort)
            {
                if (result.Count == 0)
                {
                    result.AddLast(item);
                    continue;
                }
                for (int j = 0; j < result.Count; j++)
                {
                    
                    if (item.CompareTo(result.ElementAt(j)) > 0)
                        if (j == result.Count - 1)
                        {
                            result.AddLast(item);
                            break;
                        }
                        else
                            continue;
                    if (item.CompareTo(result.ElementAt(j)) < 0 || item.CompareTo(result.ElementAt(j)) == 0)
                    {
                        result.AddBefore(result.Find(result.ElementAt(j)), item);
                        break;
                    }
                        
                }
            }
            return result.ToList();
        }
    }
}
