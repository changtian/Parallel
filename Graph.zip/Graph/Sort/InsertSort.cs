﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sort
{
    class InsertSort<T>: ISort<T> where T: IComparable
    {
        public IList<T> Sort(IList<T> toSort)
        {
            LinkedList<T> result = new LinkedList<T>();
            
            foreach (var item in toSort)
            {
                if (result.Count == 0)
                {
                    result.AddLast(item);
                    continue;
                }
                for (int j = 0; j < result.Count; j++)
                {
                    
                    if (item.CompareTo(result.ElementAt(j)) > 0)
                        if (j == result.Count - 1)
                        {
                            Console.WriteLine("Instert Value: " + item);
                            result.AddLast(item);
                            break;
                        }
                        else
                            continue;
                    if (item.CompareTo(result.ElementAt(j)) < 0 || item.CompareTo(result.ElementAt(j)) == 0)
                    {
                        Console.WriteLine("Instert Value: " + item);
                        result.AddBefore(result.Find(result.ElementAt(j)), item);
                        break;
                    }
                        
                }
            }
            return result.ToList();
        }

        public void SortCorrect(IList<T> toSort)
        {
            for (int i = 0; i < toSort.Count; i++)
            {
                int currenti = i;
                for (int j = i+1; j > 0 && j<toSort.Count; j-- )
                {
                    
                    if (toSort[j].CompareTo(toSort[j-1]) < 0)
                    {
                        var temp = toSort[j];
                        toSort[j] = toSort[j-1];
                        toSort[j-1] = temp;
                    }
                    else 
                    {
                        break;
                    }
                }
            }
        }
    }
}
