﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree
{
    class Program
    {
        static void Main(string[] args)
        {
            BinarySearchTree b = new BinarySearchTree();
            /*插入节点*/
            b.Insert(5);
            b.Insert(7);
            b.Insert(1);
            b.Insert(12);
            b.Insert(32);
            b.Insert(15);
            b.Insert(22);
            b.Insert(2);
            b.Insert(6);
            b.Insert(24);
            b.Insert(17);
            b.Insert(14);
            /*插入结束 */
            /*对二叉查找树分别进行中序，先序，后序遍历*/
            Console.Write("n中序遍历为:");
            b.InOrder(b.rootNode);
            Console.Write("n先序遍历为:");
            b.PreOrder(b.rootNode);
            Console.Write("n后序遍历为:");
            b.PostOrder(b.rootNode);
            Console.WriteLine("");
            /*遍历结束*/
            /*查最大值和最小值*/
            b.FindMax();
            b.FindMin();
            /*查找结束*/
            /*搜索节点*/
            Node x = b.Search(15);
            Console.WriteLine("n所查找的节点为" + x.data);
            /*搜索结束*/
            /*测试删除*/
            b.Delete(24);
            Console.Write("n删除节点后先序遍历的结果是:");
            b.InOrder(b.rootNode);
            b.Delete(5);
            Console.Write("n删除根节点后先序遍历的结果是:");
            b.InOrder(b.rootNode);
            Console.ReadKey();
            /*删除结束*/
        }
    }
}
