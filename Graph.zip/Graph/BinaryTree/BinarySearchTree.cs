﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree
{
    class BinarySearchTree
    {
        Node rootNode = null;
        public void Insert(int data)
        {
            Node Parent;
            //将所需插入的数据包装进节点
            Node newNode = new Node();
            newNode.data = data;

            //如果为空树，则插入根节点
            if (rootNode == null)
            {
                rootNode = newNode;
            }
            //否则找到合适叶子节点位置插入else
            {
                Node Current = rootNode;
                while (true)
                {
                    Parent = Current;
                    if (newNode.data < Current.data)
                    {
                        Current = Current.left;
                        if (Current == null)
                        {
                            Parent.left = newNode;
                            //插入叶子后跳出循环break;
                        }
                    }
                    else
                    {
                        Current = Current.right;
                        if (Current == null)
                        {
                            Parent.right = newNode;
                            //插入叶子后跳出循环break;
                        }
                    }
                }
            }
        }

        //中序
        public void InOrder(Node theRoot)
        {
            if (theRoot != null)
            {
                InOrder(theRoot.left);
                theRoot.DisplayData();
                InOrder(theRoot.right);
            }
        }
        //先序
        public void PreOrder(Node theRoot)
        {
            if (theRoot != null)
            {
                theRoot.DisplayData();
                PreOrder(theRoot.left);
                PreOrder(theRoot.right);
            }
        }
        //后序
        public void PostOrder(Node theRoot)
        {
            if (theRoot != null)
            {
                PostOrder(theRoot.left);
                PostOrder(theRoot.right);
                theRoot.DisplayData();
            }
        }

        //找到最大节点
        public void FindMax()
        {
            Node current = rootNode;
            //找到最右边的节点即可while (current.right != null)
            {
                current = current.right;
            }
            Console.WriteLine("n最大节点为:" + current.data);
 
        }
        //找到最小节点
        public void FindMin()
        {
            Node current = rootNode;
            //找到最左边的节点即可while (current.left != null)
            {
                current = current.left;
            }
            Console.WriteLine("n最小节点为:" + current.data);
        }


        //查找
        public Node Search(int i)
        {
            Node current = rootNode;
            while (true)
            {
                if (i < current.data)
                {
                    if (current.left == null)
                        break;
                    current = current.left;
                }
                else if (i > current.data)
                {
                    if (current == null)
                        break;
                    current = current.right;
                }
                else
                {
                    return current;
                }
            }
            if (current.data != i)
            {
                return null;
            }
 
            return current;
        }
    
        //删除二叉查找树中的节点，最麻烦的操作
        public Node Delete(int key)
        {
            Node parent = rootNode;
            Node current = rootNode;
            //首先找到需要被删除的节点&其父节点
            while (true)
            {
                if (key < current.data)
                {
                    if (current.left == null)
                        break;
                    parent = current;
                    current = current.left;
                }
                else if (key > current.data)
                {
                    if (current == null)
                        break;
                    parent = current;
                    current = current.right;
                }
                //找到被删除节点，跳出循环else
                {
                    break;
                }
            }
            //找到被删除节点后，分四种情况进行处理//情况一，所删节点是叶子节点时，直接删除即可
            if (current.left == null && current.right == null)
            {
                //如果被删节点是根节点，且没有左右孩子
                if (current == rootNode&&rootNode.left==null&&rootNode.right==null)
                {
                    rootNode = null;
                }
                else if (current.data < parent.data)
                    parent.left = null;
                else
                    parent.right = null;
            }
            //情况二，所删节点只有左孩子节点时
            else if(current.left!=null&&current.right==null)
            {
                if (current.data < parent.data)
                    parent.left = current.left;
                else
                    parent.right = current.left;
                
                
            }
            //情况三，所删节点只有右孩子节点时elseif (current.left == null && current.right != null)
            {
                if (current.data < parent.data)
                    parent.left = current.right;
                else
                    parent.right = current.right;
 
                
            }
            //情况四，所删节点有左右两个孩子else
            {
                //current是被删的节点，temp是被删左子树最右边的节点
                Node temp;
                //先判断是父节点的左孩子还是右孩子if (current.data < parent.data)
                {
 
                    parent.left = current.left;
                    temp = current.left;
                    //寻找被删除节点最深的右孩子while (temp.right != null)
                    {
                        temp = temp.right;
                    }
                    temp.right = current.right;
                    
                    
                }
                //右孩子elseif (current.data > parent.data)
                {
                    parent.right = current.left;
                    temp = current.left;
                    //寻找被删除节点最深的左孩子while (temp.left != null)
                    {
                        temp = temp.left;
                    }
                    temp.right = current.right;
                }
                //当被删节点是根节点，并且有两个孩子时else
                {
                    temp = current.left;
                    while (temp.right != null)
                    {
                        temp = temp.right;
                    }
                    temp.right = rootNode.right;
                    rootNode = current.left;
                }
                    
            }
            return current;
 
        }
    }
}
